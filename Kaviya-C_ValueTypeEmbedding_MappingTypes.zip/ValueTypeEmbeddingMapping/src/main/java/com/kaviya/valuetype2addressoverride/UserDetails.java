package com.kaviya.valuetype2addressoverride;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_DETAILS")
public class UserDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "User_Id")
	private int userId;

	@Column(name = "User_Name", nullable = false, length = 30)
	private String userName;

	@Column(name = "User_Phone")
	private String UserPhone;

	@Embedded
	private DoubleAddress address;

	@Embedded
	@AttributeOverrides
	({
		@AttributeOverride(name = "street", column = @Column(name = "HOME_STREET_NAME")),
			@AttributeOverride(name = "city", column = @Column(name = "HOME_CITY_NAME")),
			@AttributeOverride(name = "state", column = @Column(name = "HOME_STATE_NAME")),
			@AttributeOverride(name = "pincode", column = @Column(name = "HOME_PIN_CODE")) })
	private DoubleAddress PermanentAddress;

	@Column(name = "User_DOB")
	private Date dob;

	public DoubleAddress getPermanentAddress() {
		return PermanentAddress;
	}

	public void setPermanentAddress(DoubleAddress permanentAddress) {
		PermanentAddress = permanentAddress;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPhone() {
		return UserPhone;
	}

	public void setUserPhone(String UserPhone) {
		this.UserPhone = UserPhone;
	}

	public DoubleAddress getAddress() {
		return address;
	}

	public void setAddress(DoubleAddress address) {
		this.address = address;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

}

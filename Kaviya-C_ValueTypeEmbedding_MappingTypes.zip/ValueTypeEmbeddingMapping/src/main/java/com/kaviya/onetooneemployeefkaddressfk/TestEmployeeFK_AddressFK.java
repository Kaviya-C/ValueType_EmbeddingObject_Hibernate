package com.kaviya.onetooneemployeefkaddressfk;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestEmployeeFK_AddressFK {
		public static void main(String[] args) {
			// TODO Auto-generated method stub
					System.out.println("Storing the data");
					try {
						Configuration cfg = new Configuration();

						cfg.configure("OneToOne2Reference.cfg.xml");// populates the data of the configuration file

						// creating seession factory object
						SessionFactory factory = cfg.buildSessionFactory();
						Session session2 = factory.openSession();

						// creating transaction object
						Transaction t2 = session2.beginTransaction();

						
						
						  //creating obj for address class and giving the values
						Address ad=new Address();
						  ad.setStreet("Amritha Nagar"); 
						  ad.setCity("Coiambatore");
						  ad.setState("Tamil Nadu"); 
						  ad.setPincode("654400");
						  
						  //creating objects for user details class and giving values 
						  Employee emp=new Employee(); 
						  emp.setEmpName("Amulya Rajesh");
						 
			            
			            Address ad2=new Address();
						ad2.setStreet("Vimala Street");
						ad2.setCity("Vilupuram");
						ad2.setState("TamilNadu");
						ad2.setPincode("600008");
						
						 Employee emp2=new Employee();
				         emp2.setEmpName("Vishwa");
				            

							
				         emp.setAddress(ad);
				         ad.setEmployee(emp);
							 
			           
			            emp2.setAddress(ad2);
			            ad2.setEmployee(emp2);

				          // address is a parent class 
						session2.persist(ad2);// persisting the object
						session2.persist(emp2);
						t2.commit();// transaction is committed

						/* Serializable id=session.save(t1); */

						session2.close();

						System.out.println("successfully saved");
					} catch (Exception ex) {
						System.out.println("Problem in connection" + ex.getMessage());
					}
				


		}

	}


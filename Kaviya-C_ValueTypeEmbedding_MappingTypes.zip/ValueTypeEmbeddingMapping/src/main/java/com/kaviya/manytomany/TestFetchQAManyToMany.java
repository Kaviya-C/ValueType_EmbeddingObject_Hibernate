package com.kaviya.manytomany;

public class TestFetchQAManyToMany {

}

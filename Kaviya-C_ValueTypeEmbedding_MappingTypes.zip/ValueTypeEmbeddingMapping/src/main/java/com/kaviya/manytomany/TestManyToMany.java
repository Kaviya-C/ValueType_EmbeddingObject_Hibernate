package com.kaviya.manytomany;

import java.util.ArrayList;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestManyToMany {
	public static void main(String[] args) {
		try {
			// creating configuration object
			System.out.println("111111111111111111111");
			Configuration cfg = new Configuration();
			System.out.println("2222222222222222222222222222");
			cfg.configure("ManyToMany.cfg.xml");// populates the data of the configuration file
			System.out.println("3333333333333333333333333333");
			// creating seession factory object
			SessionFactory factory = cfg.buildSessionFactory();
			System.out.println("4444444444444444444444444");
			// creating session object
			Session session = factory.openSession();
			System.out.println("5555555555555555555555555");
			// creating transaction object
			Transaction t = session.beginTransaction();
			System.out.println("66666666666666666666666666666666");
			Answer an1 = new Answer();
			an1.setAnswername("Write Once Run Anywhere");
			an1.setPostedBy("Smriti");
			Answer an2 = new Answer();
			an2.setAnswername("Compile the java code once ,WE can Use that Class file to execute anywhere");
			an2.setPostedBy("Kaviya");
			Question q1 = new Question();
			q1.setQname("Explain about WORA?");
			ArrayList<Answer> l1 = new ArrayList<Answer>();
			l1.add(an1);
			l1.add(an2);
			q1.setAnswers(l1);
			Answer ans3 = new Answer();
			ans3.setAnswername("Class is a blueprint or template");
			ans3.setPostedBy("Reeta");
			Answer ans4 = new Answer();
			ans4.setAnswername("Class name should start with uppercase");
			ans4.setPostedBy("Deshmita");
			Question q2 = new Question();
			q2.setQname("What is an Class in Java?");
			ArrayList<Answer> l2 = new ArrayList<Answer>();
			l2.add(ans3);
			l2.add(ans4);
			q2.setAnswers(l2);
			session.persist(q1); // insert into question values()
			session.persist(q2);
			t.commit();
			session.close();
			System.out.println("SUCCESSFULLY DONE!!");
		} catch (Exception ex) {
			System.out.println("Problem in connection" + ex.getMessage());
		}
	}
}

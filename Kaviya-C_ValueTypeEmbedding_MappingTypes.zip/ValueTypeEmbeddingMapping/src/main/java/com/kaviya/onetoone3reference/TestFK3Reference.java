package com.kaviya.onetoone3reference;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestFK3Reference {
		public static void main(String[] args) {
			// TODO Auto-generated method stub
					System.out.println("Storing the data");
					try {
						Configuration cfg = new Configuration();

						cfg.configure("OneToOne3Reference.cfg.xml");// populates the data of the configuration file

						// creating seession factory object
						SessionFactory factory = cfg.buildSessionFactory();
						Session session2 = factory.openSession();

						// creating transaction object
						Transaction t2 = session2.beginTransaction();

						
						//creating obj for address class and giving the values
						Address ad=new Address();
						ad.setStreet("Thillai Nagar");
						ad.setCity("NagarKovil");
						ad.setState("Tamil Nadu");
						ad.setPincode("636008");
						
						//creating objects for user details class and giving values
			            Employee emp=new Employee();
			            emp.setEmpName("Meivizhiliyal");
			            

			            emp.setAddress(ad);
			            ad.setEmployee(emp);
			           
			            

				          // address is a parent class 
						session2.persist(ad);// persisting the object
						session2.persist(emp);
						t2.commit();// transaction is committed

						/* Serializable id=session.save(t1); */

						session2.close();

						System.out.println("successfully saved");
					} catch (Exception ex) {
						System.out.println("Problem in connection" + ex.getMessage());
					}
		}

	}




package com.kaviya.onetomanyquestionanswer;

import java.util.ArrayList;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class TestOnetoManyQsAs {
	public static void main(String[] args) {
		try {
			// creating configuration object
			System.out.println("111111111111111111111");
			Configuration cfg = new Configuration();
			System.out.println("2222222222222222222222222222");
			cfg.configure("OneToManyQAPosted.cfg.xml");// populates the data of the configuration file
			System.out.println("3333333333333333333333333333");
			// creating seession factory object
			SessionFactory factory = cfg.buildSessionFactory();
			System.out.println("4444444444444444444444444");
			// creating session object
			Session session = factory.openSession();
			System.out.println("5555555555555555555555555");
			// creating transaction object
			Transaction t = session.beginTransaction();
			System.out.println("66666666666666666666666666666666");

			Answer ans1 = new Answer();
			ans1.setAnswername("Java is a programming language");
			ans1.setPostedBy("Vembu");

			Answer ans2 = new Answer();
			ans2.setAnswername("Java is a Platform Independent");
			ans2.setPostedBy("Ramu");

			Answer ans3 = new Answer();
			ans3.setAnswername("Primitive datatypes are Predefined datatypes ");
			ans3.setPostedBy("Lalitha");

			Answer ans4 = new Answer();
			ans4.setAnswername("int float double long short boolean character byte are primitive datatypes");
			ans4.setPostedBy("Cheran");

			ArrayList<Answer> list1 = new ArrayList<Answer>();
			list1.add(ans1);
			list1.add(ans2);

			ArrayList<Answer> list2 = new ArrayList<Answer>();
			list2.add(ans3);
			list2.add(ans4);

			Question question1 = new Question();
			question1.setQname("What is Java?");
			question1.setAnswers(list1);
			Question question2 = new Question();
			question2.setQname("what is meant by Primitive datatypes? in java ");
			question2.setAnswers(list2);

			session.persist(question1);
			session.persist(question2);
			t.commit();
			session.close();
			System.out.println("success");
		} catch (Exception ex) {
			System.out.println("Problem in connection" + ex.getMessage());
		}
	}
}
